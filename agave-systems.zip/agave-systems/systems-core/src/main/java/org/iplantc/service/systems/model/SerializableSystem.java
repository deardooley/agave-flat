package org.iplantc.service.systems.model;


public interface SerializableSystem 
{
	public String toJSON();
	
}
