package org.iplantc.service.systems.model;

import java.util.Date;

public interface LastUpdatable {

	public void setLastUpdated(Date date);

}